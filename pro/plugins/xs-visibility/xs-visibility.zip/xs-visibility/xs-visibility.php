<?php
/**
 * Plugin Name:       	Block Visibility by XtremelySocial
 * Plugin URI:  		https://xtremelysocial.com/wordpress/xs-visibility/
 * Description:       	Adds visibility (show or hide) controls to numerous WordPress blocks
 * Requires at least: 	6.2
 * Requires PHP:      	7.4
 * Version:           	1.0
 * Author:            	XtremelySocial
 * Author URI:  		https://xtremelysocial.com/about/
 * License:     		GPL-2.0+
 * License URI:       	https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       	xs-visibility
 *
 * @package           	xs-visibility
 */
 
/**
 * The Block Visibility plugin adds a visibility control to various core WordPress
 * blocks. Blocks can be shown or hidden based on screen size (mobile, tablet, desktop)
 * or for logged-in users or visitors.
 */

/* Don't allow this file to be loaded directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* 
 * Plugin Class to handle instantiation and plugin functions 
 */
if ( ! class_exists( 'XS_Visibility_Plugin' ) ) {

	class XS_Visibility_Plugin {

		/**
		 * Public properties to hold our plugin version and dependencies
		 *
		 * These will be filled in below in __construct()
		 */	
		public $version = '';

		public $dependencies = '';

		/**
		 * Static property to hold our singleton instance
		 */
		static $instance = false;
	
		/**
		 * This is our constructor. Set the version and dependencies and 
		 * setup the action hooks.
		 */
		private function __construct() {

			// If we have an asset file, get the plugin version and dependencies 
			// from there.
			if ( file_exists ( __DIR__ . '/build/index.asset.php' ) ) {
				$asset_file = include( __DIR__ . '/build/index.asset.php');
				$this->version = $asset_file['version'];
				$this->dependencies = $asset_file['dependencies'];
			} else {
				$this->version = '1.0';
			}

			// Load the text translations
			add_action( 
				'plugins_loaded', 
				array( $this, 'xs_visibility_load_textdomain' ) 
			);

			// Load the back-end only assets
			add_action( 
				'enqueue_block_editor_assets', 
				array( $this, 'xs_visibility_load_block_editor_assets' ) 
			);

			// Load the assets for both front-end only
			add_action( 
				'enqueue_block_assets', //'wp_enqueue_scripts'
				array( $this, 'xs_visibility_load_block_assets' ) 
			);

		}

		/**
		 * If an instance exists, this returns it. If not, it creates one and
		 * retuns it.
		 */
		public static function getInstance() {
			//var_dump('hello, world'); //TEST
			if ( !self::$instance )
				self::$instance = new self;
			return self::$instance;
		}

		/**
		 * Setup multiple language support 
		 */
		public function xs_visibility_load_textdomain() {
			load_plugin_textdomain( 
				'xs-visibility', 
				false, 
				dirname( plugin_basename( __FILE__ ) ) . '/languages/'
			);
		}

		/**
		 * Load the pugin's CSS and Javascript on the back-end only
		 */
		public function xs_visibility_load_block_editor_assets() {
			
			if ( file_exists ( __DIR__ . '/build/index.js' ) ) {
				wp_enqueue_script(
					'xs-visibility-editor',
					__DIR__ . '/build/index.js',
					$this->dependencies,
					$this->version
				);
			}
		
			// If the plugin has an editor stylesheet, then load it
			if ( file_exists ( __DIR__ . '/build/index.css' ) ) {
				wp_enqueue_style(
					'xs-visibility-editor',
					__DIR__ . '/build/index.css',
					array(),
					$this->version
				);
			}		
		}

		/**
		 * Load the plugin's Style CSS and Javascript on the front-end only
		 */		 
		public function xs_visibility_load_block_assets() {

			// Only do this for the front-end
			if ( is_admin() ) {
				return;
			}
		
			// If the plugin has front-end javascript, then load it
			if ( file_exists ( __DIR__ . '/build/view.js' ) ) {
				wp_enqueue_script(
					'xs-visibility',
					__DIR__ . '/build/view.js',
					array('jquery'),
					$this->version,
					$in_footer = true
				);
			}
		
			// Load the plugin's main style-index.css
			if ( file_exists ( __DIR__ . '/build/style-index.css' ) ) {
				wp_enqueue_style(
					'xs-visibility',
					__DIR__ . '/build/style-index.css',
					array(),
					$this->version,
				);
			}
		}

	}

	// Instantiate our class
	$XS_Visibility_Plugin = XS_Visibility_Plugin::getInstance();
}
