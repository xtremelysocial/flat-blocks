=== Block Visibility Plugin by XtremelySocial ===
Contributors:      XtremelySocial
Stable tag:        1.0
Tags:              block
Tested up to:      6.4
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

Adds visibility controls to show or hide blocks based on screen size and/or logged-in users or visitors.

== Description ==

The Block Visibility plugin adds a visibility control to various core WordPress blocks. Blocks can be shown or hidden based on screen size (mobile, tablet, desktop) or for logged-in users or visitors.

== Installation ==

To install this plugin:

1. Upload the plugin files to the `/wp-content/plugins/xs-visibility` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the /assets directory or the directory that contains the stable readme.txt (tags or trunk). Screenshots in the /assets
directory take precedence. For example, `/assets/screenshot-1.png` would win over `/tags/4.3/screenshot-1.png`
(or jpg, jpeg, gif).
2. This is the second screen shot

== Changelog ==

= 1.0 =

* Initial plugin version

== Developer Notes ==

Enter the directory of this plugin and then you can run the following commands:

  $ npm start
	Builds the code for development and continues to watch for changes to source code

  $ npm run build
    Builds the code for production

  $ npm run format
    Formats files

  $ npm run lint:css
    Lints CSS files

  $ npm run lint:js
    Lints JavaScript files

  $ npm run plugin-zip
    Creates a zip file for a WordPress plugin

  $ npm run packages-update
    Updates WordPress packages to the latest version
