<?php
/**
 * Plugin Name:       	Block Animation by XtremelySocial
 * Plugin URI:  		https://xtremelysocial.com/wordpress/xs-animation/
 * Description:       	Adds animation controls to groups, columns, buttons, etc. to allow for various entrance and hover animations, such as fade in , zoom in, slide in.
 * Requires at least: 	6.2
 * Requires PHP:      	7.4
 * Version:           	1.0
 * Author:            	XtremelySocial
 * Author URI:  		https://xtremelysocial.com/about/
 * License:     		GPL-2.0+
 * License URI:       	https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       	xs-animation
 *
 * @package           	xs-animation
 */
 
/* Don't allow this file to be loaded directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Load the Settings Admin Class
 */
if ( file_exists( plugin_dir_path( __FILE__ ) . 'settings.php' ) ) {
	require_once plugin_dir_path( __FILE__ ) . 'settings.php';
}

/* 
 * Plugin Class to handle instantiation and plugin functions 
 */
if ( ! class_exists( 'XS_Animation_Plugin' ) ) {

	class XS_Animation_Plugin {

		/**
		 * Public properties to hold our plugin version, dependencies, and
		 * settings.
		 */	
		public $version = '';
		public $dependencies = '';
// 		public $plugin_base = '';

		/**
		 * Private vars to hold our singleton instance and settings instance
		 */
		static $instance = false;
// 		static $settings_instance = false;
	
		/**
		 * This is our constructor. Set the version and dependencies and 
		 * setup the action hooks.
		 */
		private function __construct() {

			// Set the plugin base
// 			$this->plugin_base = plugin_basename( __FILE__ );
			
			// If we have an asset file, get the plugin version and dependencies 
			// from there.
			if ( file_exists ( __DIR__ . '/build/index.asset.php' ) ) {
				$asset_file = include( __DIR__ . '/build/index.asset.php');
				$this->version = $asset_file['version'];
				$this->dependencies = $asset_file['dependencies'];
			} else {
				$this->version = '1.0';
			}

			// Instantiate the Settings class and get the settings
// 			if ( class_exists('XS_Animation_Settings') ) {
// 				$this->settings_instance = new XS_Animation_Settings();
// 			}

			// Load the text translations
			add_action( 
				'plugins_loaded', 
				array( $this, 'load_textdomain' ) 
			);

			// Load the back-end only assets
			add_action( 
				'enqueue_block_editor_assets', 
				array( $this, 'load_block_editor_assets' ) 
			);

			// Load the assets for the front-end only
			add_action( 
				'enqueue_block_assets', //'wp_enqueue_scripts'
				array( $this, 'load_block_assets' ) 
			);

		}

		/**
		 * If an instance exists, this returns it. If not, it creates one and
		 * retuns it.
		 */
		public static function getInstance() {
			if ( !self::$instance )
				self::$instance = new self;
			return self::$instance;
		}

		/**
		 * Setup multiple language support 
		 */
		public function load_textdomain() {
			load_plugin_textdomain( 
				'xs-animation', 
				false, 
				dirname( plugin_basename( __FILE__ ) ) . '/languages/'
			);
		}

		/**
		 * Load the pugin's CSS and Javascript on the back-end only
		 */
		public function load_block_editor_assets() {
			
			if ( file_exists ( __DIR__ . '/build/index.js' ) ) {
				wp_enqueue_script(
					'xs-animation-editor',
					__DIR__ . '/build/index.js',
					$this->dependencies,
					$this->version
				);
			}
		
			// If the plugin has an editor stylesheet, then load it
			if ( file_exists ( __DIR__ . '/build/index.css' ) ) {
				wp_enqueue_style(
					'xs-animation-editor',
					__DIR__ . '/build/index.css',
					array(),
					$this->version
				);
			}		
		}

		/**
		 * Load the plugin's Style CSS and Javascript on the front-end only
		 */		 
		public function load_block_assets() {

			// Only do this for the front-end
			if ( is_admin() ) {
				return;
			}
		
			// If the plugin has front-end javascript, then load it
			if ( file_exists ( __DIR__ . '/build/view.js' ) ) {
				wp_enqueue_script(
					'xs-animation',
					__DIR__ . '/build/view.js',
					array('jquery'),
					$this->version,
					$in_footer = true
				);
			}
		
			// Load the plugin's main style-index.css
			if ( file_exists ( __DIR__ . '/build/style-index.css' ) ) {
				wp_enqueue_style(
					'xs-animation',
					__DIR__ . '/build/style-index.css',
					array(),
					$this->version,
				);
			}
		}
	}

	// Instantiate our plugin class
	$XS_Animation_Plugin = XS_Animation_Plugin::getInstance();
}
